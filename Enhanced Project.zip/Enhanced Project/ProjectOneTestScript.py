from CRUD_Python_Module import AnimalShelter

def main():
    # Authenticate with your user account
    shelter = AnimalShelter("aacuser", "DD214Apr18")
    print("Connected!")

    # 1. Test CREATE
    test_data = {
        "animal_id": "TEST123",
        "name": "TestDog",
        "animal_type": "cat",
        "age_upon_outcome": "2 years"
    }
    print("CREATE:", shelter.create(test_data))

    # 2. Test READ
    print("READ:", shelter.read({"animal_id": "A746874"}))

    # 3. Test UPDATE
    print("UPDATE:", shelter.update({"animal_id": "TEST123"}, {"name": "UpdatedDog"}))

    # 4. Test READ again to verify update
    print("READ AFTER UPDATE:", shelter.read({"animal_id": "TEST123"}))

    # 5. Test DELETE
    print("DELETE:", shelter.delete({"animal_id": "TEST123"}))

    # 6. Confirm deletion
    print("READ AFTER DELETE:", shelter.read({"animal_id": "TEST123"}))

if __name__ == "__main__":
    main()
