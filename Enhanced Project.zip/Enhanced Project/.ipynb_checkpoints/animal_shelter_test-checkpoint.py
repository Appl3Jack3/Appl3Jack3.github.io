{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "2df514cf-6429-4a72-8607-e624eeb267c6",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Requirement already satisfied: pymongo in c:\\users\\armyj\\anaconda3\\lib\\site-packages (4.17.0)\n",
      "Requirement already satisfied: dnspython in c:\\users\\armyj\\anaconda3\\lib\\site-packages (2.8.0)\n",
      "Note: you may need to restart the kernel to use updated packages.\n"
     ]
    }
   ],
   "source": [
    "pip install pymongo dnspython"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "3b412d87-2b00-45fb-8668-9775e399f0c2",
   "metadata": {
    "tags": []
   },
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Connected!\n",
      "CREATE: True\n",
      "READ: [{'_id': ObjectId('6a50bb66dafc6da81aa86024'), '': 1, 'age_upon_outcome': '3 years', 'animal_id': 'A746874', 'animal_type': 'Cat', 'breed': 'Domestic Shorthair Mix', 'color': 'Black/White', 'date_of_birth': datetime.datetime(2014, 4, 10, 0, 0), 'datetime': '2017-04-11 09:00:00', 'monthyear': '2017-04-11T09:00:00', 'outcome_subtype': 'SCRP', 'outcome_type': 'Transfer', 'sex_upon_outcome': 'Neutered Male', 'location_lat': 30.5066578739455, 'location_long': -97.3408780722188, 'age_upon_outcome_in_weeks': 156.767857142857}]\n",
      "UPDATE: 1\n",
      "READ AFTER UPDATE: [{'_id': ObjectId('6a61b2de945f8e73c23736c1'), 'animal_id': 'TEST123', 'name': ' ', 'animal_type': 'cat', 'age_upon_outcome': '2 years'}]\n",
      "DELETE: 1\n",
      "READ AFTER DELETE: []\n"
     ]
    }
   ],
   "source": [
    "def main():\n",
    "    import pymongo\n",
    "    from CRUD_Python_Module import AnimalShelter\n",
    "\n",
    "    # Authenticate with your user account\n",
    "    shelter = AnimalShelter(\"aacuser\", \"DD214Apr18\")\n",
    "    print(\"Connected!\")\n",
    "    # 1. Test CREATE\n",
    "    test_data = {\n",
    "        \"animal_id\": \"TEST123\",\n",
    "        \"name\": \"TestDog\",\n",
    "        \"animal_type\": \"cat\",\n",
    "        \"age_upon_outcome\": \"2 years\"\n",
    "    }\n",
    "    print(\"CREATE:\", shelter.create(test_data))\n",
    "\n",
    "    # 2. Test READ\n",
    "    print(\"READ:\", shelter.read({\"animal_id\": \"A746874\"}))\n",
    "\n",
    "    # 3. Test UPDATE\n",
    "    print(\"UPDATE:\", shelter.update({\"name\": \"TestDog\"}, {\"name\": \" \"}))\n",
    "\n",
    "    # 4. Test READ again to verify update\n",
    "    print(\"READ AFTER UPDATE:\", shelter.read({\"animal_id\": \"TEST123\"}))\n",
    "\n",
    "    # 5. Test DELETE\n",
    "    print(\"DELETE:\", shelter.delete({\"animal_id\": \"TEST123\"}))\n",
    "\n",
    "    # 6. Confirm deletion\n",
    "    print(\"READ AFTER DELETE:\", shelter.read({\"animal_id\": \"TEST123\"}))\n",
    "\n",
    "if __name__==\"__main__\":\n",
    "    main()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "886188c6-a940-45c4-81ab-1edb3f74839b",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python [conda env:base] *",
   "language": "python",
   "name": "conda-base-py"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.13.9"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
