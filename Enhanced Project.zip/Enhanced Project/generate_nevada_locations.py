import numpy as np
import pandas as pd

# Generate 10,001 random Nevada coordinates
coords = pd.DataFrame({
    "location_lat": np.random.uniform(35.0, 42.0, 10001),      # Nevada latitude range
    "location_long": np.random.uniform(-120.0, -114.0, 10001)  # Nevada longitude range
})

coords.to_csv("nevada_coords.csv", index=False)
print("Generated nevada_coords.csv with 10,001 coordinates.")
