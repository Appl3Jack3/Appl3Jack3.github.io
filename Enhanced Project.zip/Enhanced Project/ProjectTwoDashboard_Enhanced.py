#%%
from dash import Dash
import dash_leaflet as dl
from dash import dcc, html
import plotly.express as px
from dash import dash_table
from dash.dependencies import Input, Output
import base64
import numpy as np
import pandas as pd

from CRUD_Python_Module import AnimalShelter

# -----------------------------
# Load Data From MongoDB
# -----------------------------
username = "aacuser"
password = "DD214Apr18"

db = AnimalShelter(username, password)

test_data = db.read({})
print("Records loaded:", len(test_data))

df = pd.DataFrame.from_records(test_data)

if '_id' in df.columns:
    df.drop(columns=['_id'], inplace=True)

print(df.head())
print(df.columns)

# -----------------------------
# App Setup
# -----------------------------
app = Dash(__name__)

image_filename = 'Dog_Face_compressed.png'
encoded_image = base64.b64encode(open(image_filename, 'rb').read()).decode()

app.layout = html.Div([
    html.Center(html.B(html.H1('Animal Shelter Dashboard - Rolesshania Jackson'))),
    html.Img(
        src='data:image/png;base64,{}'.format(encoded_image),
        style={'height': '180px'}
    ),
    html.Hr(),

    # Filter dropdown
    html.Div([
        html.H4("Filter by Rescue Type"),
        dcc.Dropdown(
            id='filter-type',
            options=[
                {'label': 'Water Rescue', 'value': 'Water'},
                {'label': 'Mountain', 'value': 'Mountain'},
                {'label': 'Disaster', 'value': 'Disaster'},
                {'label': 'Reset', 'value': 'Reset'}
            ],
            value='Reset',
            clearable=False,
            placeholder='Select a Rescue Type'
        )
    ]),
    html.Hr(),

    # Data table
    dash_table.DataTable(
        id='datatable-id',
        columns=[{"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns],
        data=df.to_dict('records'),
        row_selectable='single',
        selected_rows=[0],
        style_table={'overflowX': 'auto'},
        sort_action="native",
        page_current=0,
        page_size=10,
        filter_action="native"
    ),

    html.Br(),
    html.Hr(),

    # Graph + Map side by side
    html.Div(
        className='row',
        style={'display': 'flex'},
        children=[
            html.Div(
                id='graph-id',
                className='col s12 m6',
            ),
            html.Div(
                id='map-id',
                className='col s12 m6',
            )
        ]
    )
])

#############################################
# Interaction Between Components / Controller
#############################################

# 1. FILTER CALLBACK
@app.callback(
    Output('datatable-id', 'data'),
    [Input('filter-type', 'value')]
)
def update_dashboard(filter_type):

    if filter_type == "Water":
        data = db.read({
            "animal_type": "Dog",
            "breed": {"$in": ["Labrador Retriever Mix",
                              "Chesapeake Bay Retriever",
                              "Newfoundland"]},
            "sex_upon_outcome": "Intact Female"
        })

    elif filter_type == "Mountain or Wilderness Rescue":
        data = db.read({
            "animal_type": "Dog",
            "breed": {"$in": ["German Shepherd",
                              "Alaskan Malamute",
                              "Old English Sheepdog"]},
            "sex_upon_outcome": "Intact Male"
        })

    elif filter_type == "Disaster or Individual Tracking":
        data = db.read({
            "animal_type": "Dog",
            "breed": {"$in": ["Doberman Pinscher",
                              "German Shepherd",
                              "Rottweiler"]},
            "sex_upon_outcome": "Intact Male"
        })

    else:
        data = db.read({})

    dff = pd.DataFrame.from_records(data)
    if '_id' in dff.columns:
        dff.drop(columns=['_id'], inplace=True)

    return dff.to_dict('records')


# 2. STYLE HIGHLIGHT CALLBACK
@app.callback(
    Output('datatable-id', 'style_data_conditional'),
    [Input('datatable-id', 'selected_columns')]
)
def update_styles(selected_columns):
    if selected_columns is None:
        return []
    return [{
        'if': {'column_id': i},
        'background_color': '#FDE2FF'
    } for i in selected_columns]

# Update the number of graphs that will display cetain  labels
@app.callback(
    Output('graph-id', "children"),
    [Input('datatable-id', "derived_virtual_data")]
)
def update_graphs(viewData):

    if viewData is None or len(viewData) == 0:
        return html.Div("No data available")

    dff = pd.DataFrame.from_dict(viewData)

    if 'age_upon_outcome_in_weeks' not in dff.columns:
        return html.Div("Age data not available")

    # Scatter Plot
    scatter_fig = px.scatter(
        dff,
        x='animal_type',
        y='age_upon_outcome_in_weeks',
        color='breed',
        title='Age Distribution of Rescue Dogs',
        labels={'age_upon_outcome_in_weeks': 'Age (Weeks)'}
    )

    return [
        dcc.Graph(figure=scatter_fig),
    ]
# 3. AUSTIN MAP CALLBACK (ONLY ONE)
@app.callback(
    Output('map-id', 'children'),
    [
        Input('datatable-id', 'derived_virtual_data'),
        Input('datatable-id', 'derived_virtual_selected_rows')
    ]
)
def update_map(viewData, index):
    if viewData is None or index is None or len(index) == 0:
        return html.Div("Select a row to view the map location.")

    dff = pd.DataFrame.from_dict(viewData)

    # Single row selection
    row = index[0]

    # Extract coordinates + fields
    lat = float(dff.iloc[row, 13])
    lon = float(dff.iloc[row, 14])
    breed = str(dff.iloc[row, 4])
    name = str(dff.iloc[row, 9])

    # Austin, TX center
    austin_center = [30.2672, -97.7431]

    return [
        dl.Map(
            style={'width': '1000px', 'height': '500px'},
            center=austin_center,
            zoom=10,
            children=[
                dl.TileLayer(id="base-layer-id"),
                dl.Marker(
                    position=[lat, lon],
                    children=[
                        dl.Tooltip(breed),
                        dl.Popup([
                            html.H1("Animal Name"),
                            html.P(name)
                        ])
                    ]
                )
            ]
        )
    ]

if __name__ == '__main__':
    app.run(debug=True, port=8060)

#%%

#%%
